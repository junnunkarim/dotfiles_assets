# Credit

[jmw327](https://twitter.com/jmw327)
- pixelart_farm_farmer_warm-color_jmw327.png
- pixelart_house_chibi_person_game_jmw327.png
- pixelart_house_inside_girl_book_dog_jmw327.png
- pixelart_house_girl_string_cozy.png

[PixelArtJourney](https://twitter.com/PixelArtJourney)
- pixelart_night_stars_clouds_trees_cozy_PixelArtJourney.png

[RoyalNaym](https://twitter.com/RoyalNaym)
- pixelart_night_train_cozy_gas_RoyalNaym.png
- pixelart_night_train_cozy_gas_warm-color_RoyalNaym.png

[Simon S. Andersen](https://twitter.com/snakepixel)
- pixelart_arabian_palace_princess_snakepixel.png

[Makrustic](https://twitter.com/makrustic)
- pixelart_mountains_clouds_forest_makrustic.png
- pixelart_evening_trees_pole_wires_makrustic.png

[Ansitru](https://twitter.com/Ansitru)
- pixelart_medicine_flower_reminder_cattppuccin_Ansitru
- pixelart_medicine_flower_reminder_dracula_Ansitru
- pixelart_medicine_flower_reminder_nord_Ansitru

[everforest-walls](https://github.com/Apeiros-46B/everforest-walls)
- all wallpapers prefixed with _"everforest-walls"_
